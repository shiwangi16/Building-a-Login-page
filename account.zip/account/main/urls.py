from django.urls import path
from .views import login, logoutUser, home, logoutUser, register, after_login, help

urlpatterns = [
    path('', home),
    path('login', login),
    path('register', register),
    path('after_login', after_login),
    path('help', help),
    path('logout', logoutUser)
]