from django.shortcuts import redirect, render
from .forms import RegistrationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

# Create your views here.

def home(request):
    return render(request, 'home.html')

def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username = username, password = password)

        if user is not None:
            login(request, user)
            return redirect('http://localhost:8000/after_login')

        else:
            messages.info(request, 'Please enter valid credentials')

    return render (request, 'login.html')

def register(request):
    form = RegistrationForm()

    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()

            messages.success(request, 'Account created Successfully')
            return redirect('http://localhost:8000/login')

    data = { 'form' : form }
    return render (request, 'register.html', data)


def after_login(request):
    return render(request, 'after_login.html')

def help(request):
    return render(request, 'help.html')

def logoutUser(request):
    logout(request)
    return redirect('http://localhost:8000/')